test_that("rungame ends with a thank you message", {
  expect_message(rungame())
})